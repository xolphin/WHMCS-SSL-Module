<?php

/** 
 * WHMCS Client Area ENGLISH localization
 * Template and Controller localization
 * All files are overrides exists default localization files
 * Create <global $_LANG > in controller to get localization variables in each controller's functions
 * Render it global variable to template for each functions
 * Example: return [...,'lang' => $_LANG,...] - render to template
 **/
$_LANG['sslServerInstallCertificates'] = "Install Certificates";
$_LANG['sslServerSSLCert'] = "SSL Certificates Servers";
$_LANG['sslServerManageCertificate'] = "Manage Certificate";
$_LANG['sslServerValidation'] = "Validation";
$_LANG['sslServerStatusHistory'] = "Status/History";
$_LANG['sslServerReissue'] = "Reissue";
$_LANG['sslServerRenew'] = "Renew";
$_LANG['sslServerDate'] = "Date";
$_LANG['sslServerMessage'] = "Message";
$_LANG['sslServerNoDisplay'] = "Nothing to display";
$_LANG['sslServerStatHist'] = "Status and history";
$_LANG['sslServerErrorOccured'] = "An error has occured";

/** Reissue localization **/
$_LANG['sslServerCSRNoValid'] = "CSR is not valid.";
$_LANG['sslServerErrDomComp'] = "Domain or Company is wrong.";
$_LANG['sslServerInvCSR'] = "Invalid CSR.";
$_LANG['sslServerReissueSuccess'] = "Order is successfully created. After payment the request will be sent to provider";
$_LANG['sslServerReissueSent'] = "Your request has been sent. When validation is done you'll be able to download certificate";
$_LANG['sslServerReissueSert'] = "Reissue Certificate";
$_LANG['sslServerLostSert'] = "In case, <strong>you have lost your certificate</strong>, you can reissue it.<br> Press on Reissue certificate to place the order with the same data.";
$_LANG['sslServerCertInfo'] = "Certificate Information";
$_LANG['sslServerDomain'] = "Domain name";
$_LANG['sslServerAppEmail'] = "Approver e-mail";
$_LANG['sslServerExtDomain'] = "Extra Domain names";
$_LANG['sslServerValidType'] = "Validation type";
$_LANG['sslServerEmail'] = "E-mail";
$_LANG['sslServerCName'] = "CNAME";
$_LANG['sslServerUplFile'] = "Upload file";
$_LANG['sslServerCSR'] = "Your CSR";
$_LANG['sslServerCSRData'] = "CSR data";
$_LANG['sslServerComName'] = "Company Name";
$_LANG['sslServerContactInf'] = "Contact Information";
$_LANG['sslServerName'] = "Name";
$_LANG['sslServerCompany'] = "Company";
$_LANG['sslServerAddress'] = "Address";
$_LANG['sslServerStatus'] = "Status";
$_LANG['sslServerCity'] = "City";
$_LANG['sslServerZipCode'] = "Zip Code";
$_LANG['sslServerAppFirstName'] = "Approver First Name";
$_LANG['sslServerAppLastName'] = "Approver Last Name";
$_LANG['sslServerAppPhone'] = "Approver Phone";
$_LANG['sslServerManageSan'] = "In case, <strong>you want to add or remove SAN name</strong>, press on Manage SAN names";
$_LANG['sslServerManSanName'] = "Manage SAN names";
$_LANG['sslServerType'] = "Type";
$_LANG['sslServerDomain'] = "Domain";
$_LANG['sslServerHost'] = "Host";
$_LANG['sslServerValue'] = "Value";
$_LANG['sslServerAction'] = "Action";
$_LANG['sslServerMain'] = "MAIN";
$_LANG['sslServerPrice'] = "Price";
$_LANG['sslServerGroup'] = "Group";
$_LANG['sslServerProduct'] = "Product";
$_LANG['sslServerSan'] = "SAN";
$_LANG['sslServerRemove'] = "Remove";
$_LANG['sslServerValidate'] = "Validate";
$_LANG['sslServerEntExtDomain'] = "Enter extra Domain name";
$_LANG['sslServerAdd'] = "Add";
$_LANG['sslServerDelExtDomain'] = "You want to delete Extra Domain name. Are you sure ?";
$_LANG['sslServerClose'] = "Close";
$_LANG['sslServerConfirm'] = "Confirm";
$_LANG['sslServerDownload'] = "Download";
$_LANG['sslServerEnabled'] = "Enabled";
$_LANG['sslServerDisabled'] = "Disabled";
$_LANG['sslServerEnable'] = "Enable";
$_LANG['sslServerDisable'] = "Disable";
$_LANG['sslServerBack'] = "Back to Overview";
$_LANG['sslServerCertNoValid'] = "Certificate is not validated yet.";

/** Renew localization **/
$_LANG['sslServerRenewSuccess'] = "Order is successfully created. After payment the request will be sent to provider";
$_LANG['sslServerRenewCert'] = "Renew Certificate";
$_LANG['sslServerExpDate'] = "Expire date";
$_LANG['sslServerExtSan'] = "Extra SAN";
$_LANG['sslServerRenewWilSan'] = "Wildcard SAN";
$_LANG['sslServerRenewManSan'] = "Manage Renew SAN names";
$_LANG['sslServerDelSanName'] = "You want to Remove SAN name. Are you sure ?";

/** Manage localization **/
$_LANG['sslServerManageSuccess'] = "Order is successfully created. After payment the request will be sent to provider";
$_LANG['sslServerManageCert'] = "Manage SSl Certificates";
$_LANG['sslServerManageValid'] = "If the automatic certificate installation has failed, please Download certificate and install it manually. You can check the status of installation on Status/History page. The certificate will be installed during 1 day after the validation is completed successfully.";
$_LANG['sslServerManageAutoRenew'] = "Autorenew";

/** Validation localization **/
$_LANG['sslServerValidateDomValid'] = "Manual Domain Validation";
$_LANG['sslServerValidateDcvDns'] = "Place a CNAME DNS record with specific content.";
$_LANG['sslServerValidateDcvFile'] = "Add a file on your website with specific content.";
$_LANG['sslServerValidateEmailSent'] = "E-mail was sent to the chosen mailbox. Please contact WHMCS administrator if haven't received it during few days.";
$_LANG['sslServerValidateFollLink'] = "Put at the following link";
$_LANG['sslServerValidateFileBelow'] = "A file with the content below";
$_LANG['sslServerValidateProgress'] = "The validation process is in progress. Provider representative will contact you to check the Company and Contact Information. When the process is finished you will get the certificate.";
$_LANG['sslServerValidateSuccess'] = "Certificate has been validated successfully.";


/**
 * WHMCS Admin Addon SSL Sertificates localization
 * <function __smartyDisplay($vars)> - display addon admin page
 * Create <global $_LANG> and render it to template into <$vars = [...]>
 */
$_LANG['sslSertificatesOwnInst'] = "I want to install products manually on my own.";
$_LANG['sslSertificatesAutoInst'] = "I want to install product automatically (all product will be installed by default).";
$_LANG['sslSertificates'] = "SSL Certificates";
$_LANG['sslSertificatesSomeWrong'] = "Something went wrong.";
$_LANG['sslSertificatesResourceNotFound'] = "Resource not found.";
$_LANG['sslSertificatesFailCSRGen'] = "Failed to generate CSR. You do not have configured Hosting Package at WHMCS system.";

/** Client Area Shopping Cart  No Hosting**/
$_LANG['sslSertificatesNoHostDang'] = "<strong>Please buy hosting package to proceed with SSL certificate purchase. You can do this on our site through the <a href=\"http://123domain.probegin.com/cart.php\">link</a> or use services of another supplier</strong>";
$_LANG['sslSertificatesNoHostWarn'] = "<strong>Please buy hosting package to proceed with SSL certificate purchase. You can do this on our site through the <a href=\"http://123domain.probegin.com/cart.php\">link</a> or use services of another supplier.</strong>";
$_LANG['sslSertificatesCURLError'] = "CURL transfer error. Might be an issue with your SSL certificate. Try to turn on test mode inside configuration and see if it works.";
$_LANG['sslSertificatesServerReachError'] = "Unable to reach the server or something went wrong. See debug log for more info or/and contact us.";

/** Admin Addon helper localization **/
$_LANG['sslSertificatesTempNotFound'] = "Could not load template: %s";
$_LANG['sslSertificatesSSLDbError'] = "SSL Certificates error occured on DB structure update: ";

/** Admin Addon api localization **/
$_LANG['sslSertificatesUnableGroups'] = "Unable to install Groups";
$_LANG['sslSertificatesUnableProducts'] = "Unable to install Products";
$_LANG['sslSertificatesUnableGetProducts'] = "Unable to get Products";
$_LANG['sslSertificatesGreenColor'] = "green";
$_LANG['sslSertificatesSuccessCreated'] = "successfully <strong>created</strong>.";

/** Admin Addon jsrouter localization **/
$_LANG['sslSertificatesWHMCSLimitations'] = "<p>Please, note: sometimes real error can't be printed here due to WHMCS limitations. Please, see Module Log for all requests information.</p>";

/** Client Area Manage Product localization **/
$_LANG['sslSertificatesEnabAutorenew'] = "Autorenew has been enabled.";
$_LANG['sslSertificatesDisabAutorenew'] = "Autorenew has been disabled.";
$_LANG['sslSertificatesInvoiceSuccess'] = "Invoice %d has been sent successfully.";
$_LANG['sslSertificatesNotFound'] = "Certificate not found.";
$_LANG['sslSertificatesFailCertDownl'] = "Failed to download certificate. Certificate is not validated yet.";
$_LANG['sslSertificatesFailCreateDir'] = "Failed to create directory: %s";
$_LANG['sslSertificatesFailExtZIP'] = "Failed to extract ZIP archive.";
$_LANG['sslSertificatesFailCertInst'] = "Can not install certificate %s. Reason: %s";
$_LANG['sslSertificatesCancReqCert'] = "Request for cancellation certificate id: %d";
$_LANG['sslSertificatesFailCancReqCert'] = "Failed to cancel certificate. Reason: %s";
$_LANG['sslSertificatesFailCreateReqCert'] = "Failed to create order certificate. Reason: %s";
$_LANG['sslSertificatesSuccessCertCreate'] = "Certificate has been ordered successfully.";
$_LANG['sslSertificatesFailReissueCert'] = "Failed to reissue order certificate. Reason: %s";
$_LANG['sslSertificatesReissueCertOrdSuccess'] = "Reissue certificate has been ordered successfully.";
$_LANG['sslSertificatesValidCNAMESuccess'] = "Successfull certificate validation by CNAME";
$_LANG['sslSertificatesValidFileSuccess'] = "Successfull certificate validation by FILE";
$_LANG['sslSertificatesWHMCSAdminContact'] = "Please contact WHMCS administrator to configure your hosting package.";
$_LANG['sslSertificatesFailValidCert'] = "Failed to validate certificate. Reason: %s";
$_LANG['sslSertificatesInstNoImp'] = "Instance '%s' is not implemented yet.";
$_LANG['sslSertificatesUnableFindRemServ'] = "Unable to find remote server or server is inactive for the domain %s.";
$_LANG['sslSertificatesRenewCertSuccess'] = "Renew certificate has been successfully . Certificate ID";
$_LANG['sslSertificatesAddSANSuccess'] = "Add SAN name has been successfully . Certificate ID";
$_LANG['sslSertificatesStatUpd'] = "Status was updated. Certificate ID";
$_LANG['sslSertificatesSuccessValidUpd'] = "Certificates was successfully validated. Status was updated. Certificate ID";
$_LANG['sslSertificatesInitDown'] = "# Initial Download and Install Certificate ID : ";
$_LANG['sslSertificatesForDom'] = " For Domain ";
$_LANG['sslSertificatesSSLCertInstSuccess'] = "SSL Certificate has been installed successfully.";
$_LANG['sslSertificatesSSLFailInst'] = "Failed to install SSL Certificates. Reason: ";
$_LANG['sslSertificatesWHMCSContAdm'] = "Please contact with WHMCS administrator. Reason: ";
$_LANG['sslSertificatesValidProg'] = "The validation process is in progress. Reason : ";
$_LANG['sslSertificatesReqID'] = " Request ID: ";
$_LANG['sslSertificatesNoHosting'] = "<strong>Please buy hosting package to proceed with SSL certificate purchase. You can do this on
                            our site through the <a href=\"http://123domain.probegin.com/cart.php\">link</a> or use services of another supplier</strong>";
$_LANG['sslSertificatesNoOneHosting'] = "<strong>Please buy hosting package to proceed with SSL certificate purchase. You can do this on our site through
                            the <a href=\"http://123domain.probegin.com/cart.php\">link</a> or use services of another supplier.</strong>";
$_LANG['sslSertificatesDaysExp'] = "You can renew certificate only 60 days before its expire.";
$_LANG['sslSertificatesSure'] = "Are you sure?";

/** Client Area Additional Required Information **/
$_LANG['sslInformationDomName'] = "Enter your Domain name";
$_LANG['sslInformationInfoMultidomain'] = "<strong>Multidomain certificate can not be validated and installed automatically.
                                            You will need to validate it manually according to the type, you choose.
                                            <br>After order and payment are completed, you will be able to check the Validation instructions in your Services.
                                            <br>The certificate will be available in your Services after validation process is completed successfully.
                                        </strong>";
$_LANG['sslInformationValidDomEm'] = "Enter valid domain to be able to get E-mails for approving";
$_LANG['sslInformationSelAppEmail'] = "Select approver e-mail";
$_LANG['sslInformationSelValidType'] = "Select validation type";
$_LANG['sslInformationCSR'] = "CSR Information";
$_LANG['sslInformationDataContentCSR'] = "A <a href=\"https://en.wikipedia.org/wiki/Certificate_signing_request\"
                           target=\"blank\"> Certificate Signing Request </a> is a code that you create on the
                           Web server where the certificate must be installed on. This is a piece of encrypted text
                           containing information about your server and to request certificate. CSR paste it into the
                           field below. We recommend that you generate a CSR of at least 2048 bits. This looks
                           something like this:
                           <br> ----- BEGIN CERTIFICATE REQUEST-----<br>
                           MIICzTCCAbUCAQAwgYcxCzAJBgNVBAYTAk5MMRYwFAYDVQQIEw1Ob29yZC1Ib2xs&gt;
                           <br>YW5kMRYwFAYDVQQHEw1IZWVyaHVnb3dhYXJkMSEwHwYDVQQKExhYb2xwaGluIFNT<br>
                           .....
                           <br>xg==<br>
                           -----END CERTIFICATE REQUEST -----";
$_LANG['sslInformationEmailValid'] = "<strong>Email validation</strong><br>
                               Email will be sent to mailboxes admin-, administrator-, webmaster-, hostmaster-, of postmaster@domainname.tld<br>
                               <strong>CNAME validation</strong><br>
                               Place a CNAME DNS record with specific content.<br>
                               <strong>File validation</strong><br>
                               Place a file on your website with specific content.";
$_LANG['sslInformationCertTypeWild'] = "<div class='col-xs-6 bg-info infoWildcard' style='width: 75%;'> Please, note that CSR for <strong>Wildcard</strong> certificate can not be generated automatically on Plesk Webserver. <br>Please generate it manually and proceed with option <strong>'I have my own hosting package'</strong>.</div>";
$_LANG['sslInformationOnlyComodo'] = "You try to enter WILDCARD domain. Only Comodo MULTI supported it.";
$_LANG['sslInformationEntDomName'] = "Please enter a Domain name.";
$_LANG['sslInformationNoHostPack'] = "You don't have a Hosting Packages at WHMCS System. <br> Please buy Hosting package or contact WHMCS Administrator to resolve the problem.";
$_LANG['sslInformationOrderCompSSL'] = "After you complete the order it will be placed with the SSL certificates provider. Validation data and status will be available in your Services. The certificate will be available in your Services after validation process is completed successfully.";
$_LANG['sslInformation'] = "";