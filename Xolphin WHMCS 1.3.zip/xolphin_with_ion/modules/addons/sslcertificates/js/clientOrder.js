$(document).Loading();
$(document).ready(function () {
    
    function _x(STR_XPATH) {
        var xresult = document.evaluate(STR_XPATH, document, null, XPathResult.ANY_TYPE, null);
        var xnodes = [];
        var xres;
        while (xres = xresult.iterateNext()) {
            xnodes.push(xres);
        }

        return xnodes;
    }

    var customfields = $('.customfields');
    var selectPackage = $('.package');
    var ordercustomfields = $('.ordercustomfields');
    var uid = $('input[name=checkPackage]').attr('value');
    var certificateType = $('input[name=certificateType]').val();
    var certificateGroupName = $('input[name=cetrificate_group_name]').val();
    var continueOrder = $("button[type=submit]");
    var confOptExtra,
            confOptWildcard;
            
    var contentYes;
    var contentOutside
    
    /**
     * Click by Submit button 
     * Problem: page has 2 elements with same attr id
     * Then we must detach no selected html block element with id
     * And later appendTo page when selected other point and submit form
     */
    $('#continueButton').click(function(){
        var packageTypeHidden = $('#package_type_hidden').val();
        
        if(packageTypeHidden === 'yes') {
            if($('#man-notif, .accountOutsideHosting, #contact-info-man').length > 0){
                contentYes = $('#man-notif, .accountOutsideHosting, #contact-info-man');
                contentYes = contentYes.detach();
            }
        } else if(packageTypeHidden === 'outside') {
            if(certificateType === 'MULTI') {
                if($('.infoMultidomain, #auto-notif, .successCheck, #contact-info-auto').length > 0) {
                    contentOutside = $('.infoMultidomain, #auto-notif, .successCheck, #contact-info-auto');
                    contentOutside = contentOutside.detach();
                }
            } else {
                if($('#auto-notif, .successCheck, #contact-info-auto').length > 0) {
                    contentOutside = $('#auto-notif, .successCheck, #contact-info-auto');
                    contentOutside = contentOutside.detach();
                }
            }
        } 
    });
    

    confOptExtra = $(_x('//*[@id="submit-form"]/div[2]/div[1]/div[2]/input'));
    confOptExtra.attr('readonly', true);
    if (certificateGroupName == 'GeoTrust') {
        confOptExtra.val(-4);
    } else {
        confOptExtra.val(-1);
    }
    if ($(_x('//*[@id="submit-form"]/div[2]')).children().length > 1) {
        confOptWildcard = $(_x('//*[@id="submit-form"]/div[2]/div[2]/div[2]/input'));
        confOptWildcard.attr('readonly', true);
    }

    String.prototype.capitalize = function () {
        return this.charAt(0).toUpperCase() + this.slice(1);
    };

    customfields.css('border-bottom', '10px solid white');
    customfields.css('border-top', 'none');

    if ($('input[name=checkCart]').val() == "false") {
        ordercustomfields.height(122);
    }

    if (certificateType == "WILDCARD") {
//        var infoWildcard = "<div class='col-xs-6 bg-info infoWildcard' style='width: 75%;'> " +
//                "Please, note that CSR for <strong>Wildcard</strong> certificate can not be generated automatically " +
//                "on Plesk Webserver. <br>Please generate it manually " +
//                "and proceed with option <strong>'I have my own hosting package'</strong>.</div>";
        var infoWildcard = lang['sslInformationCertTypeWild'];
        $(infoWildcard).appendTo(ordercustomfields); 
    }
    
    selectPackage.click(function () {
        var autoTemplate = $('input[name=auto-template]').val();
        var manuallyTemplate = $('input[name=manually-template]').val();
        var template = $('input[name=noHosting]').val();
        $('#no, #no-one, .accountOutsideHosting, #contact-info-man, #auto-notif, #man-notif, .successCheck, #contact-info-auto, .infoMultidomain').css('display','none');

        $(this).each(function () {
            $('.infoWildcard').css('display', 'none');
            
            if ($(this).attr('value') == 'yes') {
                
                $('#package_type_hidden').val('yes');
                $('.successCheck, #contact-info-auto').css('display','block');
                $('#man-notif, #auto-notif').css('display','none');
                $('#continueButton').removeAttr('disabled');
                $('#validationType').css('border-color','#ccc');
                
                if(typeof contentOutside != 'undefined') {
                    contentOutside.appendTo('.customfields').css('display','block');
                }
                
                continueOrder.attr('value', 'yes');
                $.ajax({
                    method: "POST",
                    url: location.href,
                    data: {checkHosting: 1}
                })
                        .done(function (result) {
                            if (result == "true") {
                                
                                /* Load Template*/
                                //customfields.load(autoTemplate, function () {
                                    $.ajax({
                                        method: "POST",
                                        url: location.href,
                                        data: {getContactDetails: 1}
                                    })
                                            .done(function (result) {
                                                var contactInfo = JSON.parse(result);
                                                $('#company').val(contactInfo.companyname);
                                                $('#address').val(contactInfo.address1);
                                                $('#city').val(contactInfo.city);
                                                $('#zipcode').val(contactInfo.postcode);
                                                $('#approverFirstName').val(contactInfo.firstname);
                                                $('#approverLastName').val(contactInfo.lastname);
                                                $('#approverPhone').val(contactInfo.phonenumber.substr(1));
                                            });
                                    customfields.height(540);
                                    var extra = $('.extra').css('display', 'none');
                                    if (certificateGroupName != "Comodo") {
                                        $('#validationType option[value=DNS]').attr('disabled', true);
                                        $('#validationType option[value=FILE]').attr('disabled', true);
                                    }
                                    var notifications = $('#auto-notif').css('display', 'none');
                                    var approverEmails = $('.approver-emails').css('display', 'none');
                                    var extraDomainListDiv = $('.extraDomainList').css('display', 'none');
                                    if (certificateType == "MULTI") {
                                        extra.css('display', 'block');
                                        $('.infoMultidomain').css('display', 'block');
                                        customfields.height(630);
                                    }
                                    $('.successCheck #add_extra_domain').unbind('click').click(function () {
                                        var domainName = $('.successCheck').find('#extra_domain');
                                        if (domainName.val() == "") {
                                            domainName.css('border-color', 'red');
                                        } else if (domainName.val().match(/^(\*\.)/) && certificateGroupName != "Comodo") {
                                            $(".error-message").html(lang['sslInformationOnlyComodo']);
                                            $(".modal").modal('show');
                                            $(".modal").on('hidden.bs.modal', function (e) {
                                                domainName.css('border-color', 'red');
                                            });
                                        } else {
                                            var customHeights = customfields.height();
                                            var confOptExtraValue = parseInt(confOptExtra.val());

                                            if (!domainName.val().match(/^(\*\.)/)) {
                                                confOptExtra.val(confOptExtraValue + 1);
                                                confOptExtraValue = parseInt(confOptExtra.val());
                                            }

                                            if (confOptWildcard) {
                                                var confOptWildcardValue = parseInt(confOptWildcard.val());
                                                if (domainName.val().match(/^(\*\.)/)) {
                                                    confOptWildcard.val(confOptWildcardValue + 1);
                                                    confOptWildcardValue = parseInt(confOptWildcard.val());
                                                }
                                            }

                                            domainName.css('border-color', '#ccc');
                                            var listData = domainName.val().split('\n');
                                            var listContainer = $('.successCheck').find('#extra-domain-list');
                                            var numberOfListItems = listData.length;
                                            var listItem = "<li></li>";

                                            for (var i = 0; i < numberOfListItems; ++i) {
                                                if (listData[i] != "") {
                                                    $(listItem).appendTo(listContainer).html(listData[i] +
                                                            '<button style="margin-left: 5px;" ' +
                                                            'class="btn btn-default btn-xs btn-danger removeDomain">x</button>'
                                                            );
                                                    if ((customHeights - $('.successCheck').height()) < 34) {
                                                        customfields.height(customHeights + 34);
                                                        customHeights = customfields.height();
                                                    }
                                                }
                                            }

                                            $('.successCheck #extra-domain-list .removeDomain').click(function () {
                                                if (customHeights >= 630) {
                                                    customfields.height(customHeights - 34);
                                                    customHeights = customfields.height();
                                                }

                                                if (confOptWildcard) {
                                                    if ($(this).parent().text().match(/^(\*\.)/)) {
                                                        confOptWildcard.val(confOptWildcardValue - 1);
                                                        confOptWildcardValue = parseInt(confOptWildcard.val());
                                                    }
                                                }

                                                if (!$(this).parent().text().match(/^(\*\.)/))
                                                {
                                                    confOptExtra.val(confOptExtraValue - 1);
                                                    confOptExtraValue = parseInt(confOptExtra.val());
                                                }
                                                $(this).parent().remove();
                                            });

                                            extraDomainListDiv.css('display', 'block');
                                            domainName.val("");
                                        }
                                    });

                                    $('#getApproverEmails').click(function () {
                                        var domainInput = $('#domain');
                                        var domain = domainInput.val();

                                        if (domain == "" && certificateType != "MULTI") {
                                            domainInput.css('border-color', 'red');
                                            $(".error-message").html(lang['sslInformationEntDomName']);
                                            $(".modal").modal('show');
                                        } else {
                                            if (domain.match(/^(([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|([a-zA-Z0-9][a-zA-Z0-9-_]{1,61}[a-zA-Z0-9]))\.([a-zA-Z]{2,6}|[a-zA-Z0-9-]{2,30}\.[a-zA-Z]{2,3})$/) == null) {
                                                domainInput.css('border-color', 'red');
                                            } else {
                                                domainInput.css('border-color', '#ccc');
                                                $.ajax({
                                                    method: "POST",
                                                    url: location.href,
                                                    data: {
                                                        domain: domain,
                                                        certType: certificateType,
                                                        getEmails: true
                                                    }
                                                })
                                                        .done(function (result) {
                                                            domainInput.css('border-color', '#ccc');
                                                            var emails = JSON.parse(result);
                                                            if (emails.message) {
                                                                $('.error-result').html(emails.message);
                                                                notifications.css('display', 'block');
                                                            } else {
                                                                notifications.css('display', 'none');
                                                                var select = $('#approverEmail');
                                                                var option = $('#approverEmail option');

                                                                if (option.length !== 0) {
                                                                    select.find('option')
                                                                            .remove()
                                                                            .end()
                                                                }
                                                                $.each(emails, function (index, value) {
                                                                    select.append($('<option>', {
                                                                        value: value,
                                                                        text: value
                                                                    }));
                                                                });
                                                                approverEmails.css('display', 'block');
                                                            }
                                                        });
                                            }
                                        }
                                    });
                                //});
                            } else {
                                customfields.height(75);
                                $(".error-message").html(lang['sslInformationNoHostPack']);
                                $(".modal").modal('show');
                            }
                        });
            } else if ($(this).attr('value') == 'outside') {
                
                continueOrder.attr('value', 'no');
                $('.accountOutsideHosting, #contact-info-man').css('display','block');
                $('#package_type_hidden').val('outside');
                $('#auto-notif').css('display','none');
                $('#continueButton').removeAttr('disabled');
                $('#validationType').css('border-color','#ccc');
                
                if(typeof contentYes != 'undefined') {
                    contentYes.appendTo('.customfields').css('display','block');
                }
                
                //customfields.load(manuallyTemplate, function () {
                    $.ajax({
                        method: "POST",
                        url: location.href,
                        data: {getContactDetails: 1}
                    })
                            .done(function (result) {
                                var contactInfo = JSON.parse(result);
                                if (contactInfo.length != 0) {
                                    $('#company').val(contactInfo.companyname);
                                    $('#address').val(contactInfo.address1);
                                    $('#city').val(contactInfo.city);
                                    $('#zipcode').val(contactInfo.postcode);
                                    $('#approverFirstName').val(contactInfo.firstname);
                                    $('#approverLastName').val(contactInfo.lastname);
                                    $('#approverPhone').val(contactInfo.phonenumber.substr(1));
                                }
                            });
                    customfields.height(590);
                    var extra = $('.extra').css('display', 'none');
                    $('.accountOutsideHosting #add_extra_domain').unbind('click').click(function () {
                        var domainName = $('.accountOutsideHosting').find('#extra_domain');
                        if (domainName.val() == "") {
                            domainName.css('border-color', 'red');
                        } else if (domainName.val().match(/^(\*\.)/) && certificateGroupName != "Comodo") {
                            $(".error-message").html(lang['sslInformationOnlyComodo']);
                            $(".modal").modal('show');
                            $(".modal").on('hidden.bs.modal', function (e) {
                                domainName.css('border-color', 'red');
                            });
                        } else {
                            var customHeights = customfields.height();
                            var confOptExtraValue = parseInt(confOptExtra.val());

                            if (!domainName.val().match(/^(\*\.)/)) {
                                confOptExtra.val(confOptExtraValue + 1);
                                confOptExtraValue = parseInt(confOptExtra.val());
                            }

                            if (confOptWildcard) {
                                var confOptWildcardValue = parseInt(confOptWildcard.val());
                                if (domainName.val().match(/^(\*\.)/)) {
                                    confOptWildcard.val(confOptWildcardValue + 1);
                                    confOptWildcardValue = parseInt(confOptWildcard.val());
                                }
                            }

                            domainName.css('border-color', '#ccc');
                            var listData = domainName.val().split('\n');
                            var listContainer = $('.accountOutsideHosting').find('#extra-domain-list');
                            var numberOfListItems = listData.length;
                            var listItem = "<li></li>";
                            for (var i = 0; i < numberOfListItems; ++i) {
                                if (listData[i] != "") {
                                    $(listItem).appendTo(listContainer).html(listData[i] +
                                            '<button style="margin-left: 5px;" ' +
                                            'class="btn btn-default btn-xs btn-danger removeDomain">x</button>'
                                            );
                                    customfields.height(customHeights + 34);
                                    customHeights = customfields.height();
                                }
                            }

                            $('.accountOutsideHosting #extra-domain-list .removeDomain').click(function () {
                                if (customHeights >= 630) {
                                    customfields.height(customHeights - 34);
                                    customHeights = customfields.height();
                                }

                                if (confOptWildcard) {
                                    if ($(this).parent().text().match(/^(\*\.)/)) {
                                        confOptWildcard.val(confOptWildcardValue - 1);
                                        confOptWildcardValue = parseInt(confOptWildcard.val());
                                    }
                                }

                                if (!$(this).parent().text().match(/^(\*\.)/))
                                {
                                    confOptExtra.val(confOptExtraValue - 1);
                                    confOptExtraValue = parseInt(confOptExtra.val());
                                }
                                $(this).parent().remove();
                            });

                            extraDomainListDiv.css('display', 'block');
                            domainName.val("");
                        }
                    });
                    if (certificateGroupName != "Comodo") {
                        $('#validationType option[value=DNS]').attr('disabled', true);
                        $('#validationType option[value=FILE]').attr('disabled', true);
                    }
                    var popoverInfo = $('.info-popover');

                    popoverInfo.popover({html: true});
                    popoverInfo.on('click', function (e) {
                        popoverInfo.not(this).popover('hide');
                    });

                    $('.accountOutsideHosting img').attr('src', $('input[name=img]').val());
                    var notifications = $('#man-notif').css('display', 'none');
                    var approverEmails = $('.approver-emails').css('display', 'none');
                    var labelCompany = $('#label_company');
                    var labelDomain = $('#label_domain');
                    var extraDomainListDiv = $('.extraDomainList').css('display', 'none');

                    if (certificateType == "MULTI") {
                        extra.css('display', 'block');
                    }
                    $('textarea[name=csr]').bind('input propertychange', function () {
                        if ($(this).val() != "") {
                            $.ajax({
                                method: "POST",
                                url: location.href,
                                data: {csr: $(this).val()}
                            })
                                    .done(function (result) {
                                        var decode = JSON.parse(result);
                                        if (decode.message) {
                                            $('#man-notif .error-result').html(decode.message);
                                            notifications.css('display', 'block');
                                        } else {
                                            notifications.css('display', 'none');
                                            labelCompany.html(decode.company);
                                            labelDomain.html(decode.cn);
                                            $('textarea[name=csr]').css('border-color', '#ccc');

                                            $.ajax({
                                                method: "POST",
                                                url: location.href,
                                                data: {
                                                    domain: decode.cn,
                                                    certType: certificateType,
                                                    getEmails: true
                                                }
                                            })
                                                    .done(function (result) {
                                                        var emails = JSON.parse(result);
                                                        if (emails.message) {
                                                            $('.error-result').html(emails.message);
                                                            notifications.css('display', 'block');
                                                        } else {
                                                            notifications.css('display', 'none');
                                                            var select = $('.accountOutsideHosting #approverEmail');
                                                            var option = $('.accountOutsideHosting #approverEmail option');

                                                            if (option.length !== 0) {
                                                                select.find('option')
                                                                        .remove()
                                                                        .end();
                                                            }
                                                            $.each(emails, function (index, value) {
                                                                select.append($('<option>', {
                                                                    value: value,
                                                                    text: value
                                                                }));
                                                            });
                                                            if (certificateType == "MULTI") {
                                                                customfields.height(customfields.height() + $('.approver-emails').height());
                                                            }
                                                            approverEmails.css('display', 'block');
                                                        }
                                                    }
                                                    );
                                        }
                                    });
                        } else {
                            $(this).css('border-color', 'red');
                        }
                    });
                //});
            } else if ($(this).attr('value') == 'no') {
                
                continueOrder.attr('value', 'no');
                template = template + " #no";
                customfields.height(75);
                
                $('#package_type_hidden').val('no');
                $('#no').css('display','block');
                customfields.css('border-bottom', '10px solid #5AB9F1');
                $('#continueButton').attr('disabled','disabled');
                
//                customfields.load(template, function (response) {
//                    customfields.height(75);
//                    customfields.css('border-bottom', '10px solid #5AB9F1');
//                });

            } else {
                continueOrder.attr('value', 'no');
                template = template + " #no-one";
                customfields.height(75);
                
                $('#package_type_hidden').val('no-one');
                $('#no-one').css('display','block');
                customfields.css('border-bottom', '10px solid #5AB9F1');
                $('#continueButton').attr('disabled','disabled');
                
//                customfields.load(template, function () {
//                    customfields.height(75);
//                    customfields.css('border-bottom', '10px solid #5AB9F1');
//                });

            }
        });

    });

    $("#submit-form").submit(function (event) {
        event.preventDefault();

        var form = this;
        var contactFields = {
            company: $('#company').val(),
            address: $('#address').val(),
            city: $('#city').val(),
            zipcode: $('#zipcode').val(),
            approverFirstName: $('#approverFirstName').val(),
            approverLastName: $('#approverLastName').val(),
            approverPhone: $('#approverPhone').val(),
            kvk: $('#kvk').val(),
            reference: $('#reference').val()
        };
        var notifications = $('.notifications').css('display', 'none');
        
        if (customfields.children().length === 0) {
            $(".error-message").html('Please select a package.');
            $(".modal").modal('show');
            return false;
        }
        
        if (continueOrder.val() == 'yes') {
            var validateOptionYes = $('#validationType');
            var domain = $('#domain').val();
            if (certificateType == "MULTI") {
                var liArray = $('#extra-domain-list li');
                var liValues = [];
                $.each(liArray, function (index, value) {
                    var text = $(this).text();
                    text = text.substring(0, text.length - 1);
                    liValues.push(text);
                });
                extraDomains = liValues;
            }

            if (validateOptionYes.val() != "") {

                $.ajax({
                    method: "POST",
                    url: location.href,
                    cache: false,
                    data: {
                        uid: uid,
                        generateCSR: true,
                        domain: domain,
                        extraDomains: extraDomains,
                        dcvType: validateOptionYes.val(),
                        approverEmail: $('#approverEmail').val(),
                        certificateType: certificateType,
                        certificateGroup: $("input[name=cetrificate_group_name]").val(),
                        contactFields: contactFields
                    }
                }).done(function (result) {
                    if (result == "true") {
                        $(".error-message").html(lang['sslInformationOrderCompSSL']);
                        $(".modal").modal('show');
                        notifications.css('display', 'none');
                        $(".modal").on('hidden.bs.modal', function (e) {
                            var confOptExtraValue = parseInt(confOptExtra.val());
                            if (confOptExtraValue < 0) {
                                confOptExtra.val(0);
                            }
                            form.submit();
                        });
                    } else {
                        var response = JSON.parse(result);
                        var text = "";
                        if (response.errors) {
                            var i = 1;
                            $.each(response.errors, function (index, value) {
                                text = text.concat(i + ". " + index.capitalize() + " : " + value + "<br>");
                                i++;
                            });
                        }
                        $('.error-result').html(response.message + "<br>" + text);
                        notifications.css('display', 'block');
                        customfields.height(customfields.height() + notifications.height());
                        return false;
                    }
                });
            } else {
                $('#validationType').css('border-color', 'red');
            }
        } else {
            var validateOptionNo = $('#validationType');
            var extraDomains = $('#extra_domain').val();
            if (certificateType == "MULTI") {
                var extraLiArray = $('#extra-domain-list li');
                var extraLiValues = [];
                $.each(extraLiArray, function (index, value) {
                    var text = $(this).text();
                    text = text.substring(0, text.length - 1);
                    extraLiValues.push(text);
                });
                extraDomains = extraLiValues;
            }
            if (validateOptionNo.val() != "") {
                if (notifications.height() != 32) {
                    customfields.height(customfields.height() - notifications.height());
                }
                if (uid == "") {
                    uid = 0;
                }
                $.ajax({
                    method: "POST",
                    url: location.href,
                    cache: false,
                    data: {
                        certificateType: certificateType,
                        dcvType: validateOptionNo.val(),
                        csr: $('textarea[name=csr]').val(),
                        approverEmail: $('#approverEmail').val(),
                        uid: uid,
                        extraDomains: extraDomains,
                        contactFields: contactFields
                    }
                })
                        .done(function (result) {
                            if (result == "true") {
                                $(".error-message").html(lang['sslInformationOrderCompSSL']);
                                $(".modal").modal('show');
                                notifications.css('display', 'none');
                                $(".modal").on('hidden.bs.modal', function (e) {
                                    var confOptExtraValue = parseInt(confOptExtra.val());
                                    if (confOptExtraValue < 0) {
                                        confOptExtra.val(0);
                                    }
                                    form.submit();
                                });
                            } else {
                                var response = JSON.parse(result);
                                var text = "";
                                var i = 1;
                                $.each(response.errors, function (index, value) {
                                    text = text.concat(i + ". " + index.capitalize() + " : " + value + "<br>");
                                    i++;
                                });
                                $('.error-result').html(response.message + "<br>" + text);
                                customfields.height(customfields.height() + notifications.height());
                                notifications.css('display', 'block');
                                return false;
                            }
                        });
            } else {
                $('#validationType').css('border-color', 'red');
            }
        }
    });
});