$(document).ready(function () {
    var selected = [];

    $('#auto_install').css('display', 'none');
    $('.install_products').css('display', 'none');

    $('input[type=radio]').click(function () {
        if ($('input[value=auto]').is(":checked")) {
            $('#auto_install').css('display', 'block');
            $('.install_products').css('display', 'block');
        }
        if ($('input[value=manually]').is(":checked")) {
            $('#auto_install').css('display', 'none');
            $('.install_products').css('display', 'none');
        }
    });

    $('#auto').click(function () {
        $("input:checkbox[name=groups]:checked").each(function () {
            selected.push($(this).val());
        });

        $.ajax({
            method: "POST",
            url: location.href,
            data: {groups: selected}
        })
                .done(function (result) {
                    selected.length = 0;
                    $('#contentarea').html(result);
                });
    });

    $('#manually').click(function () {
        $("input:checkbox[name=groups]:checked").each(function () {
            if (!$(this).attr("disabled")) {
                selected.push($(this).val());
            }
        });
        $.ajax({
            method: "POST",
            url: location.href,
            data: {groups: selected}
        })
                .done(function (result) {
                    selected.length = 0;
                    $('#contentarea').html(result);
                });
    });
});